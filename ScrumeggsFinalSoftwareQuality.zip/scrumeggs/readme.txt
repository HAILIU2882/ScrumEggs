Operation instructions:

git clone https://github.com/COMP3900-9900-Capstone-Project/capstoneproject-comp9900-h13a-scrumeggs.git  
(or unzip scrumeggs.zip file)

If cloned from git : cd capstoneproject-comp9900-h13a-scrumeggs/scrumeggs/  
If unzipped : cd scrumeggs/

Run commands:
make install  
make run_backend  

In the same terminal:  
make run_frontend  
  
To terminate, kill backend with 'pkill python' command as it is set to run in the background.

After opening the browser, the webapp will be available at localhost:3000/login
The database was pre-populated with a number of users. To log in, use one of the following credentials:

tom.cruise@gmail.com
old.nan@gmail.com
sansa.stark@gmail.com

The password for all is 111.



